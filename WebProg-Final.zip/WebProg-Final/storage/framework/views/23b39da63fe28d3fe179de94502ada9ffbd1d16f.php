<?php $__env->startSection('title'); ?>
    <title>Purchase History</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
    #content {
        width: 800px;
        padding-top: 40px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="content" class="center">
        <div class="center">
            <a href="<?php echo e(url('home')); ?>"><button>Return to product</button></a>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div id="cart-header">
                <div><?php echo e($cart->checkout_at); ?> <label class="right">Total: <?php echo e($cart->sumTotalPrice()); ?>.00</label></div>
            </div>
            <table id="table-data-cart">
            <?php $__currentLoopData = $cart->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($transaction->product->name); ?></td>
                    <td>Rp<?php echo e($transaction->product->price); ?>.00</td>
                    <td>Quantity: <?php echo e($transaction->quantity); ?></td>
                    <td>Sub Total: Rp<?php echo e($transaction->subTotal()); ?>.00</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div>You don't have any Transaction</div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LH-PC\WebProg-Final\resources\views/history.blade.php ENDPATH**/ ?>