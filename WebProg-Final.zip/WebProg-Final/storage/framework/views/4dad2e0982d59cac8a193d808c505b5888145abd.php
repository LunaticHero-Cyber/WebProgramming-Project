<?php $__env->startSection('title'); ?>
    <title>Product - <?php echo e($product->name); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
    #content {
        height: 1000px;
        width: 900px;
        padding-top: 30px;
    }

    #item-container {
        flex-direction: row;
        flex-wrap: wrap;
    }

    .items {
        width: 900px;
        height: 500px;
        padding: 15px;
        border: 10px rgb(255, 210, 168) solid;
        background-color: rgb(255, 210, 168);
        margin: 10px;
        border-radius: 10px;
    }

    .items img {
        width: 300px;
        height: 300px;
    }

    .item-name {
        margin-top: 15px;
    }

    .item-name p{
        color: black;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 16px;
    }

    .item-desc {
        margin-top: 10px;
    }

    .item-name p{
        color: rgb(58, 58, 58);
    }

    .item-quantity {
        margin-top: 5px;
    }

    .item-quantity p{
        color: black;
    }

    .item-price {
        margin-top: 35px;
    }

    .item-price p{
        color: black;
    }

    .item-form {
        margin-top: 20px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="content" class="center">
        <div class="center">
            <a href="<?php echo e(url('home')); ?>"><button>Return to product</button></a>
        </div>
        <div class="items">
            <img src="/product-image/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>">
            <div class="item-name">
                <p><?php echo e($product->name); ?></p>
            </div>
            <div class="item-desc">
                <p><?php echo e($product->description); ?></p>
            </div>
            <div class="item-price">
                <p>Price: Rp. <?php echo e($product->price); ?>,00-</p>
            </div>
            <div class="item-quantity">
                <p>Quantity: <?php echo e($product->quantity); ?></p>
            </div>
            <div class="item-form">
                <form method="POST" action="/addToCart/<?php echo e($product->id); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="number" name="qty" placeholder="0" min="0">
                    <button type="submit" name="submit" id="add-cart-btn">Add to Cart</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LH-PC\WebProg-Final2\WebProg-Final\resources\views/product.blade.php ENDPATH**/ ?>