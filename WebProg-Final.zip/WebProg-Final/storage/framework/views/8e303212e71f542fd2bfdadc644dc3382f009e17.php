<?php $__env->startSection('title'); ?>
    <title>Login</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
    #form-login {
        width: 600px;
        padding: 20px;
    }

    #content {
        height: 1000px;
        width: 95%;
        padding-top: 30px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="content" class="center">
        <div id="form-login" class="center">
            <form action="<?php echo e(url('login')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div>
                    <input class="standard-input" type="email" placeholder="Email" name="email">
                </div>
                <div class="margin-top">
                    <input class="standard-input" type="password" placeholder="Password" name="password">
                </div>
                <div class="margin-top">
                    <input type="submit">
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LH-PC\WebProg-Final\resources\views/login.blade.php ENDPATH**/ ?>