<?php $__env->startSection('title'); ?>
    <title>Cart</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
    #content {
        width: 800px;
        padding-top: 40px;
    }

    .right-btn{
        float: right;
        border: 2px solid black;
    }

    .submit-btn{
        background-color: lightgreen;
        border: 2px solid green;
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div id="content" class="center">
    <div class="right-btn">
            <a href="<?php echo e(url('home')); ?>">Return to product</a>
    </div>
    <br>
    <br>
        <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div id="transaction-div">
                <div id="stationary-name-div">
                    Order: <?php echo e($transaction->product->name); ?>

                </div>
                <div id="price-qty-div">
                    <ul>
                        <li>
                            <div id="stationary-price-div">
                                Price: <?php echo e($transaction->product->price); ?>

                            </div>
                        </li>
                        <li>
                            <div id="stationary-quantity-div">
                                Quantity: <?php echo e($transaction->quantity); ?>

                            </div>
                        </li>
                    </ul>                 
                </div>
                <hr>
                <div id="total-checkout-div">
                    <div id="subtotal-div">
                        Total Rp<?php echo e($transaction->product->price*$transaction->quantity); ?>.00
                    </div>
                    <br>
                </div>  
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Do Some Transaction to see your products in cart</p>
        <?php endif; ?>

        <?php if(count($transactions)): ?>
            <a href="/cart/<?php echo e($cart->id); ?>" id="checkout-btn" class='submit-btn'>Check Out</a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Kevin Yatshen\Downloads\WebLecFinal\WebProg-Final\resources\views/cart.blade.php ENDPATH**/ ?>