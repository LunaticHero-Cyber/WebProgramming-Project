<?php $__env->startSection('title'); ?>
    <title>Home</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
    #content {
        height: 1000px;
        width: 60%;
        padding-top: 30px;
    }

    #item-container {
        flex-direction: row;
        flex-wrap: wrap;
    }

    .items {
        width: 250px;
        height: 350px;
        padding: 15px;
        border: 10px rgb(255, 210, 168) solid;
        background-color: rgb(255, 210, 168);
        margin: 10px;
        border-radius: 10px;
    }

    .items img {
        width: 250px;
        height: 250px;
    }

    .item-name {
        margin-top: 15px;
    }

    .item-name p{
        color: black;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 16px;
    }

    .item-desc {
        margin-top: 10px;
    }

    .item-name p{
        color: rgb(58, 58, 58);
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="content" class="center">
        <div id="item-container" class="inline-flex">

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/product/<?php echo e($product->id); ?>">
                    <div class="items">
                        <img src="/product-image/<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>">
                        <div class="item-name">
                            <p><?php echo e($product->name); ?></p>
                        </div>
                        <div class="item-desc">
                            <p><?php echo e($product->description); ?></p>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Kevin Yatshen\Downloads\WebLecFinal\WebProg-Final\resources\views/home.blade.php ENDPATH**/ ?>