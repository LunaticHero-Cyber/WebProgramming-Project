<?php $__env->startSection('title'); ?>
    <title>Cart</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
    #content {
        width: 800px;
        padding-top: 40px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="content" class="center">
        <div class="center">
            <a href="<?php echo e(url('home')); ?>"><button>Return to product</button></a>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div id="transaction-div">
                <div id="stationary-name-div">
                    Stationary name: <?php echo e($transaction->product->name); ?>

                </div>
                <div id="price-qty-div">
                    <ul>
                        <li>
                            <div id="stationary-price-div">
                                Stationary price: <?php echo e($transaction->product->price); ?>

                            </div>
                        </li>
                        <li>
                            <div id="stationary-quantity-div">
                                Quantity: <?php echo e($transaction->quantity); ?>

                            </div>
                        </li>
                    </ul>                 
                </div>
                <hr>
                <div id="total-checkout-div">
                    <div id="subtotal-div">
                        Total Rp<?php echo e($transaction->product->price*$transaction->quantity); ?>.00
                    </div>
                </div>  
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Do Some Transaction to see your products in cart</p>
        <?php endif; ?>

        <?php if(count($transactions)): ?>
            <a href="/cart/<?php echo e($cart->id); ?>"><button id="checkout-btn">CheckOut</button></a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LH-PC\WebProg-Final\resources\views/cart.blade.php ENDPATH**/ ?>